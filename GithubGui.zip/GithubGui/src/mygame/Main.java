package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.input.InputManager;
import com.jme3.input.KeyInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.niftygui.NiftyJmeDisplay;
import com.jme3.renderer.Camera;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Geometry;
import com.jme3.scene.shape.Box;
import de.lessvoid.nifty.Nifty;
//import static com.sun.deploy.uitoolkit.impl.fx.ui.MixedCodeInSwing.show;
import java.awt.Button;
import java.awt.Label;
//import com.jme3.niftygui.NiftyJmeDisplay;

/**
 * This is the Main Class of your Game. You should only do initialization here.
 * Move your Logic into AppStates or Controls
 * @author normenhansen
 */
public class Main extends SimpleApplication{
    Button playBut; boolean play=false;
    InputManager im;
    Nifty nifty;
    NiftyJmeDisplay nf;
    boolean playNow=false;

    public static void main(String[] args) {
        Main app = new Main();
        app.start();
    }

    @Override
    public void simpleInitApp() {
        Box b = new Box(1, 1, 1);
        Geometry geom = new Geometry("Box", b);

        Material mat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setColor("Color", ColorRGBA.Blue);
        geom.setMaterial(mat);

        rootNode.attachChild(geom);
        
        //Inisialisasi Nifty
        nf = NiftyJmeDisplay.newNiftyJmeDisplay(assetManager, inputManager, audioRenderer, viewPort);
        nifty = nf.getNifty();
        nifty.fromXml("Interface/FrontPageR2.xml", "GScreen0", new MauMenuScreenController());
        
        //Memunculkan hasil dari nifty ke layar
        guiViewPort.addProcessor(nf);
        
        //Menerima input
        inputManager.addMapping("play", new KeyTrigger(KeyInput.KEY_SPACE) );
        inputManager.addListener(actionListener, "play");
        Label l;
        nifty.getCurrentScreen();
        
    }
    
    
    @Override
    public void simpleUpdate(float tpf) {
        //TODO: add update code     
        if(playNow){
            System.out.println("yea");
            playNow = false;
            nifty.exit();
        }
    }

    @Override
    public void simpleRender(RenderManager rm) {
        //TODO: add render code
    }

    
    
    private final ActionListener actionListener = new ActionListener(){
        @Override
        public void onAction(String name, boolean isPressed, float tpf) {
            if(name.equals("play")){
                System.out.println("yes");
                nifty.exit();
                playNow = true;
            }
        }
        
    };
}
