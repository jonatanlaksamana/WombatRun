/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import com.jme3.asset.AssetManager;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.font.BitmapText;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;

/**
 *
 * @author A S U S
 */
public class Scene extends AbstractAppState {

   public AssetManager assetManager;
 public   Node localRootNode = new Node("scene");
  public  Node rootNode;

    public Scene(SimpleApplication app) {
        rootNode = app.getRootNode();
        assetManager = app.getAssetManager();
        Spatial scene = assetManager.loadModel("Models/Sinbad/Sinbad.j3o");//Masukan sinbad ke scene
        localRootNode.attachChild(scene);//masangin scene ke local

    }

    public void setScene() {
        //Spatial scene = assetManager.loadModel("Scenes/TestScene.j3o");
        Spatial scene = assetManager.loadModel("Models/Sinbad/Sinbad.j3o");//Masukan sinbad ke scene
        localRootNode.attachChild(scene);//masangin scene ke local
        scene.getParent().rotate(0, -190, 0);

    }

    public Spatial getModelScene() {
        Spatial hsl = assetManager.loadModel("Models/Sinbad/Sinbad.j3o");
        localRootNode.attachChild(hsl);//masangin scene ke local
        return hsl;

    }


}
