
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.animation.AnimChannel;
import com.jme3.animation.AnimControl;
import com.jme3.animation.AnimEventListener;
import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import com.jme3.app.state.AppStateManager;
import com.jme3.asset.AssetManager;
import com.jme3.bounding.BoundingBox;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.control.CharacterControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.input.ChaseCamera;
import com.jme3.input.FlyByCamera;
import com.jme3.input.InputManager;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.audio.AudioNode;
import com.jme3.font.BitmapFont;
import com.jme3.font.BitmapText;
import com.jme3.font.Rectangle;
import com.jme3.input.controls.ActionListener;
import com.jme3.math.Quaternion;
import java.util.Random;

/**
 *
 * @author A S U S
 */
public class GameLogic extends AbstractAppState implements AnimEventListener, ActionListener {

    private Node rootNode;
    private Node localRootNode = new Node("terrain");
    private AssetManager assetManager;
    private InputManager inputManager;
    private BulletAppState bulletAppState;
    private Spatial player, obs2;
    private CharacterControl playerControl;
    private FlyByCamera flyByCamera;
    private Camera camera;
    private ChaseCamera chaseCam;
    RigidBodyControl obsCon;
    BitmapFont fnt;
    BitmapText text;
    BitmapFont defaultFont;
    BitmapText fpsScoreText, pressStart;
    private boolean statusPause = false;
    private AudioNode audioJump, nodeBGM, audioTabrak, audioRun;

    private final Vector3f playerWalkDirection = Vector3f.ZERO;
    private boolean left = false, right = false, up = false, down = false, jump = false;
    private boolean status = false;
    private AnimChannel animationChannel;
    private AnimChannel shootingChannel;
    private AnimControl animationControl;
    private float airTime = 0;
    private Scene sc;
    private Audio audio;
    private Obstacle obs;
    private Obstacle obsx2, obsx3;
    private Obstacle obsy2, obsy3;
    private Spatial kayu2, kayu3, bird2, bird3;
    private int score = 0;
    private Random rand;

    private Spatial bird;
    private RigidBodyControl obsCon2, obsConKayu2, obsConKayu3, obsConBird2, obsConBird3;

    private Obstacle obsBird;

    private Vector3f temp;
    private Player charz;
    private Spatial floor;

    private Sky langit;
    private Movement mov;
    int speed;
    Vector3f sizeKayu = new Vector3f(1f, 0f, 1f);

    public GameLogic(SimpleApplication app) {
        rootNode = app.getRootNode();
        assetManager = app.getAssetManager();
        inputManager = app.getInputManager();
        flyByCamera = app.getFlyByCamera();
        camera = app.getCamera();
        fnt = assetManager.loadFont("Interface/Fonts/Default.fnt");
        text = new BitmapText(fnt);
        sc = new Scene(app);
        audio = new Audio(app);
        obs = new Obstacle(app);

        obsBird = new Obstacle(app);
        charz = new Player(app);
        rand = new Random();
        langit = new Sky(app);
        mov = new Movement(app);
        obsx2 = new Obstacle(app);
        obsx3 = new Obstacle(app);
        obsy3 = new Obstacle(app);
        obsy2 = new Obstacle(app);
        speed = 25;

    }

    //tanahVoid
    public void Tanah() {
        floor = localRootNode.getChild("Tanah");
        floor.rotate(0, 0, 0);

        bulletAppState.getPhysicsSpace().add(floor.getControl(RigidBodyControl.class));

    }

    //font 
    private void loadText(BitmapText txt, String text, BitmapFont font, float x, float y, float z) {
        txt.setSize(font.getCharSet().getRenderedSize());
        txt.setLocalTranslation(txt.getLineWidth() * x, txt.getLineHeight() * y, z);
        txt.setText(text);
        localRootNode.attachChild(txt);
    }

    public void obstacleKayu2() {
        kayu2 = obsx2.getObstacle("Models/Fence 01/Fence 01.j3o");
        sizeKayu.set(1f, 0.9659078f, 2f);
        kayu2.setLocalScale(sizeKayu);
        kayu2.rotate(0, 180, 0);
        obsConKayu2 = obsx2.a("Models/Fence 01/Fence 01.j3o", player, obsConKayu2);
        kayu2.addControl(obsConKayu2);
        localRootNode.attachChild(kayu2);
        bulletAppState.getPhysicsSpace().add(obsConKayu2);
        obsConKayu2.setPhysicsLocation(new Vector3f(-100, 1, this.RandomZPos()));

    }

    public void obstacle() {
        obs2 = obs.getObstacle("Models/Fence 01/Fence 01.j3o");
        obs2.setLocalScale(1f, 0f, 1f);
        obs2.rotate(0, 180, 0);
        obsCon = obs.a("Models/Fence 01/Fence 01.j3o", player, obsCon);

        obs2.addControl(obsCon);
        localRootNode.attachChild(obs2);
        bulletAppState.getPhysicsSpace().add(obsCon);
        obsCon.setPhysicsLocation(new Vector3f(-100f, 0.99419403f, 0.4776468f));

    }

    public void obstacleBird() {
        bird = obsBird.getObstacle("Models/cloud/cloud.j3o");

        bird.setLocalScale(0.008f, 0.01f, 0.01f);
        bird.rotate(0, 180, 0);

        obsCon2 = obsBird.a("Models/Bird_Asset/Bird_Asset.j3o", player, obsCon2);

        bird.addControl(obsCon2);
        localRootNode.attachChild(bird);

        bulletAppState.getPhysicsSpace().add(obsCon2);
        obsCon2.setPhysicsLocation(new Vector3f(-100f, 0.99419403f, 0.4776468f));

    }

    public int RandomZPos() {
        int rand = this.rand.nextInt(5) - 2;
        return rand;

    }

    public int randomYpos() {
        int rand = this.rand.nextInt(6) + 5;

        return rand;

    }

    public int randomX() {
        int hasil = this.rand.nextInt((51) + 50) * -1;
        return hasil;
    }

    public void setPhysic() {
        //etupAnimationController();
        bulletAppState = new BulletAppState();
        bulletAppState.setDebugEnabled(false);

    }

    public void setScene() {
        //Spatial scene = assetManager.loadModel("Scenes/TestScene.j3o");

        Spatial scene = sc.getModelScene();//Masukan sinbad ke scene
        localRootNode.attachChild(scene);//masangin scene ke local
        scene.getParent().rotate(0, -190, 0);

    }

    public void createPlayer() {
        player = localRootNode.getChild("Player");

        BoundingBox boundingBox = (BoundingBox) player.getWorldBound();

        float rad = boundingBox.getXExtent();
        float height = boundingBox.getYExtent();
        CapsuleCollisionShape playerShape = new CapsuleCollisionShape(rad, height);
        playerControl = new CharacterControl(playerShape, 1.0f);
        player.addControl(playerControl);
        bulletAppState.getPhysicsSpace().add(playerControl);
        playerControl.setPhysicsLocation(new Vector3f(-40f, 0.99419403f, 0.4776468f));

        this.movement();

    }

    public void movement() {
        //Animation
        animationControl = mov.getAnim(player);
        animationControl.addListener(this);
        animationChannel = animationControl.createChannel();
        mov.getInput(actionListener);

    }

    private void createSky() {
        Spatial langitz = this.langit.createSky();
        localRootNode.attachChild(langitz);

    }

    public void initAudioJump() {

        audioJump = audio.initAudioJump();
        localRootNode.attachChild(audioJump);
    }

    public void initAudioTabrak() {
        /* Berbunyi jika tabrakan. */
        audioTabrak = audio.initAudioTabrak();
        localRootNode.attachChild(audioTabrak);
    }

    public void jumpSound() {
        nodeBGM = audio.jumpSound();
        localRootNode.attachChild(nodeBGM);
        nodeBGM.play();

    }

    public void score() {
        //score
        defaultFont = assetManager.loadFont("Interface/Fonts/Default.fnt");
        pressStart = new BitmapText(defaultFont, false);
        fpsScoreText = new BitmapText(defaultFont, false);

        loadText(fpsScoreText, "Current Score: 0", defaultFont, 0, 2 + 5, 0);
        loadText(pressStart, "PRESS ENTER", defaultFont, 0, 5 + 5, 0);

        text.setBox(new Rectangle(0, 0, 1360, 768));
        text.setSize(fnt.getPreferredSize() * 2f);
        text.setText("jojo");
        text.setLocalTranslation(0, 5, 0);
        localRootNode.attachChild(text);

    }

    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);
        this.jumpSound();
        this.setPhysic();
        stateManager.attach(bulletAppState);
        rootNode.attachChild(localRootNode);
        this.setScene();
        this.Tanah();
        initAudioJump();
        initAudioTabrak();
        this.createSky();
        this.createPlayer();
        flyByCamera.setEnabled(false);
        chaseCam = new ChaseCamera(camera, player, inputManager);

        //obs2 part
        this.obstacle();
        this.obstacleKayu2();

        this.obstacleBird();

    }

    protected final ActionListener actionListener = new ActionListener() {
        @Override
        public void onAction(String name, boolean keyPressed, float tpf) {
            if (keyPressed) {
                animationChannel.setAnim("RunBase");

            }

            if (name.equals(
                    "Pause") && !keyPressed) {
                setEnabled(!isEnabled());
            } else if (name.equals("Up")) {
                up = true;

            } else if (name.equals(
                    "Down")) {
                up = false;
                down = keyPressed;
                up = false;

            } else if (name.equals(
                    "Left")) {
                up = false;

                left = keyPressed;

            } else if (name.equals("Right")) {
                up = false;
                right = keyPressed;

            } else if (name.equals(
                    "Jump")) {

                playerControl.jump();
                playerControl.setJumpSpeed(20);

                if (keyPressed) {
                    animationChannel.setAnim("JumpLoop");
                    audioJump.playInstance(); // membunyikan suara sekali
                } else {
                    animationChannel.setAnim("IdleBase");
                    animationChannel.setAnim("RunBase");

                }
            } else if (name.equals("Go")) { // go
                statusPause = true;
                playerControl.setPhysicsLocation(new Vector3f(-40f, 0.99419403f, 0.4776468f));
                obsCon.setPhysicsLocation(new Vector3f(-100f, 0.99419403f, 0.4776468f));
                obsCon2.setPhysicsLocation(new Vector3f(-100f, 0.99419403f, 0.4776468f));
                score += 1;
                System.out.println(score + "ini score");

            } else if (name.equals("Pausez")) // pause 
            {
                statusPause = false;
            } else if (name.equals("Resume") && statusPause == false) // resume
            {
                statusPause = true;

            }

            if (!keyPressed) {
                up = false;
            }

        }
    };

    @Override
    public void update(float tpf) {
        Vector3f camDir = camera.getDirection().clone();
        Vector3f camLeft = camera.getLeft().clone();
        camDir.y = 0;
        camLeft.y = 0;

        Vector3f dir = new Vector3f(-0.96940863f, 0.0f, 0.018936336f);
        chaseCam.setDefaultDistance(10f);
        chaseCam.setDefaultVerticalRotation(0.25f);

        camDir.normalizeLocal();
        camLeft.normalizeLocal();

        playerWalkDirection.set(0, 0, 0);
        playerControl.setViewDirection(camLeft);

        if (left) {
            playerWalkDirection.add(camLeft);
            playerWalkDirection.set(0, 0, 5);

        }
        if (right) {
            playerWalkDirection.add(camLeft.negate());
            playerWalkDirection.set(0, 0, -5);
        }
        if (up) {
            playerWalkDirection.add(camDir);
            //playerWalkDirection.set(-5, 0, 0);

        }
        if (down) {
            playerWalkDirection.add(camDir.negate());
            //playerWalkDirection.set(5, 0, 0);
        }

        if (player != null) {
            playerWalkDirection.multLocal(10f).multLocal(tpf);
            playerControl.setWalkDirection(playerWalkDirection);
        }

        if (statusPause == true) {
            nodeBGM.play();

            if (obsCon.getPhysicsLocation().x < -10) {

                obsCon.setPhysicsLocation(new Vector3f(obsCon.getPhysicsLocation().x + tpf * speed, obsCon.getPhysicsLocation().y, obsCon.getPhysicsLocation().z));
                obsCon2.setPhysicsLocation(new Vector3f(obsCon2.getPhysicsLocation().x + tpf * speed, obsCon2.getPhysicsLocation().y, obsCon2.getPhysicsLocation().z));

                obsConKayu2.setPhysicsLocation(new Vector3f(obsConKayu2.getPhysicsLocation().x + tpf * speed, obsConKayu2.getPhysicsLocation().y, obsConKayu2.getPhysicsLocation().z));

            } else {
                

                obsCon.setPhysicsLocation(new Vector3f(-200, 0.99419403f, this.RandomZPos()));
                obsConKayu2.setPhysicsLocation(new Vector3f(-200, 1, this.RandomZPos()));

                obsCon2.setPhysicsLocation(new Vector3f(-175, this.randomYpos(), this.RandomZPos()));

            }

            if (playerControl.getPhysicsLocation().x > -39 || playerControl.getPhysicsLocation().z <= -2.7206101 || playerControl.getPhysicsLocation().z >= 2.7206101) {

                statusPause = false;
                speed = 25;
                animationChannel.setAnim("Dance");
                score = 0;
                System.out.println("reset" + score);

                audioTabrak.playInstance();
                nodeBGM.stop();

            }

        }
    }

    @Override
    public void onAnimCycleDone(AnimControl control, AnimChannel channel, String animName) {

    }

    @Override
    public void onAnimChange(AnimControl control, AnimChannel channel, String animName) {

    }

    @Override
    public void onAction(String name, boolean isPressed, float tpf) {

    }

}
