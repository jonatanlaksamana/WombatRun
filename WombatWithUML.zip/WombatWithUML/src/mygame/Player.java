/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import com.jme3.asset.AssetManager;
import com.jme3.bounding.BoundingBox;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.control.CharacterControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;

/**
 *
 * @author A S U S
 */
public class Player extends Scene {

    public AssetManager assetManager;
    public Node localRootNode;

    public Player(SimpleApplication app) {
        super(app);
        assetManager = super.assetManager;
        this.localRootNode = super.localRootNode;

    }

    public Spatial getModelPlayer() {
        Spatial scene = this.getModelScene();
        localRootNode.attachChild(scene);
        Spatial hasil = localRootNode.getChild("Player");
        return hasil;
    }

    public CharacterControl getCharacterControl() {
      Spatial player = this.getModelPlayer();
        
        
        BoundingBox boundingBox = (BoundingBox) player.getWorldBound();
        float rad = boundingBox.getXExtent();
        float height = boundingBox.getYExtent();
        CapsuleCollisionShape playerShape = new CapsuleCollisionShape(rad, height);
        return new CharacterControl(playerShape, 1.0f);
    }

}
