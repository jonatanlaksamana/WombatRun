/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import com.jme3.asset.AssetManager;
import com.jme3.scene.Spatial;
import com.jme3.util.SkyFactory;

/**
 *
 * @author A S U S
 */
public class Sky  extends AbstractAppState{
    AssetManager assetManager;
    
    /**
     * Constructor kelas Sky
     * @param app 
     */
    public Sky ( SimpleApplication app)
    {
        assetManager = app.getAssetManager();
        
    }
    
    /**
     * Inisialisasi langit
     * @return 
     */
    public Spatial createSky()
    {
        Spatial hsl = SkyFactory.createSky(assetManager, "Textures/Sky/Bright/BrightSky.dds", false);
        return hsl;
        
    }
            

            
}
