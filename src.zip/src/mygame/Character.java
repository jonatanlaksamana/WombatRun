/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.bounding.BoundingBox;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.control.CharacterControl;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;

/**
 *
 * @author A S U S
 */
public class Character {
    GameLogic gl;
    CharacterControl playerControl;
    
    /**
     * Constructor kelas Character
     */
    public Character() {
        //this.gl = gl;
    }
    
    /**
     * Untuk membuat player
     * @param player
     * @param localRootNode 
     */
    public void createPlayer(Spatial player,Node localRootNode) {
        player = localRootNode.getChild("Player");

        BoundingBox boundingBox = (BoundingBox) player.getWorldBound();

        float rad = boundingBox.getXExtent();
        float height = boundingBox.getYExtent();
        CapsuleCollisionShape playerShape = new CapsuleCollisionShape(rad, height);
        playerControl = new CharacterControl(playerShape, 1.0f);
        
        //bulletAppState.getPhysicsSpace().add(playerControl);
        //playerControl.setPhysicsLocation(new Vector3f(-40f, 0.99419403f, 0.4776468f));
        
        
        //gl.movement();

    }
    
    /**
     * Untuk mendapatkan CharacterControl
     * @return 
     */
    public CharacterControl getPlayerControl(){
        return playerControl;
    }
}
