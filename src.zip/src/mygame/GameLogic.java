
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.animation.AnimChannel;
import com.jme3.animation.AnimControl;
import com.jme3.animation.AnimEventListener;
import com.jme3.animation.Animation;
import com.jme3.animation.SpatialTrack;
import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import com.jme3.app.state.AppStateManager;
import com.jme3.asset.AssetManager;
import com.jme3.bounding.BoundingBox;
import com.jme3.bounding.BoundingVolume;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.control.CharacterControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.cinematic.Cinematic;
import com.jme3.cinematic.events.AnimationEvent;
import com.jme3.input.ChaseCamera;
import com.jme3.input.FlyByCamera;
import com.jme3.input.InputManager;
import com.jme3.input.KeyInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.light.Light;
//import com.jme3.light.LightProbe;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.scene.Geometry;
//import com.jme3.renderer.Camera;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Box;
import com.jme3.terrain.Terrain;
import com.jme3.animation.Animation;
import com.jme3.audio.AudioData;
import com.jme3.audio.AudioData.DataType;
import com.jme3.audio.AudioNode;
import com.jme3.collision.CollisionResult;
import com.jme3.collision.CollisionResults;
import java.util.HashMap;
import com.jme3.font.BitmapFont;
import com.jme3.font.BitmapText;
import com.jme3.font.Rectangle;
import com.jme3.font.LineWrapMode;
import com.jme3.font.Rectangle;
import com.jme3.input.KeyInput;
import com.jme3.input.RawInputListener;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.event.*;
import com.jme3.util.SkyFactory;
import java.util.Random;

/**
 *
 * @author A S U S
 */
public class GameLogic extends AbstractAppState implements AnimEventListener, ActionListener {

    Node rootNode;
    Node localRootNode = new Node("terrain");
    AssetManager assetManager;
    InputManager inputManager;
    BulletAppState bulletAppState;
    Spatial player, obs2;
    CharacterControl playerControl;
    FlyByCamera flyByCamera;
    Camera camera;
    ChaseCamera chaseCam;
    RigidBodyControl obsCon;
    BitmapFont fnt;
    BitmapText text;
    boolean statusPause = false;
    AudioNode audioJump, nodeBGM, audioTabrak, audioRun;
    BitmapFont defaultFont;
    //textField
    BitmapText fpsScoreText, pressStart;
   

    final Vector3f playerWalkDirection = Vector3f.ZERO;
    boolean left = false, right = false, up = false, down = false, jump = false;
    boolean status = false;
    //animation
    AnimChannel animationChannel;
    AnimChannel shootingChannel;
    AnimControl animationControl;
    float airTime = 0;
    Scene sc;
    Audio audio;
    Obstacle obs;
    Obstacle obsY;
    int score = 0;
    Random rand;

    Spatial bird;
    RigidBodyControl obsCon2;
    Obstacle obsBird;

    Vector3f temp;
    Player charz;
    Spatial floor;

    Sky langit;
    Movement mov;
    Character chara;
    
    /**
     * Constructor GameLogic untuk mencreate bahan-bahan yang dibutuhkan
     * @param app 
     */
    public GameLogic(SimpleApplication app) {
        rootNode = app.getRootNode();
        assetManager = app.getAssetManager();
        inputManager = app.getInputManager();
        flyByCamera = app.getFlyByCamera();
        camera = app.getCamera();
        fnt = assetManager.loadFont("Interface/Fonts/Default.fnt");
        text = new BitmapText(fnt);
        sc = new Scene(app);
        audio = new Audio(app);
        obs = new Obstacle(app);
        obsY = new Obstacle(app);
        obsBird = new Obstacle(app);

        charz = new Player(app);
        rand = new Random();
        langit = new Sky(app);
        mov = new Movement(app);
        chara = new Character();
    }

    /**
     * Untuk inisialisasi tanah
     */
    //tanahVoid
    public void Tanah() {
        floor = localRootNode.getChild("Tanah");
        floor.rotate(0, 0, 0);

        bulletAppState.getPhysicsSpace().add(floor.getControl(RigidBodyControl.class));

    }

    /**
     * Untuk mengatur/manajemen tulisan
     * @param txt
     * @param text
     * @param font
     * @param x
     * @param y
     * @param z 
     */
    //font 
    private void loadText(BitmapText txt, String text, BitmapFont font, float x, float y, float z) {
        txt.setSize(font.getCharSet().getRenderedSize());
        txt.setLocalTranslation(txt.getLineWidth() * x, txt.getLineHeight() * y, z);
        txt.setText(text);
        localRootNode.attachChild(txt);
    }

    /**
     * Obstacle pertama yang berupa pagar
     */
    public void obstacle() {
        obs2 = obs.getObstacle("Models/Fence 01/Fence 01.j3o");
        obs2.setLocalScale(1f, 0f, 1f);
        obs2.rotate(0, 180, 0);
        obsCon = obs.a("Models/Fence 01/Fence 01.j3o", player, obsCon);

        obs2.addControl(obsCon);
        localRootNode.attachChild(obs2);
        bulletAppState.getPhysicsSpace().add(obsCon);
        obsCon.setPhysicsLocation(new Vector3f(-100f, 0.99419403f, 0.4776468f));

    }

    /**
     * Obstacle kedua
     */
    public void obstacleBird() {
        bird = obsBird.getObstacle("Models/Bird_Asset/Bird_Asset.j3o");
        bird.setLocalScale(20f, 3f, 20f);
        bird.rotate(0, 180, 0);

        obsCon2 = obsBird.a("Models/Bird_Asset/Bird_Asset.j3o", player, obsCon2);

        bird.addControl(obsCon2);
        localRootNode.attachChild(bird);

        bulletAppState.getPhysicsSpace().add(obsCon2);
        obsCon2.setPhysicsLocation(new Vector3f(-100f, 0.99419403f, 0.4776468f));

    }

    /**
     * Untuk random posisi axis Z
     * @return int hasil random;
     */
    public int RandomZPos() {
        int rand = this.rand.nextInt(5) - 2;
        return rand;

    }

    /**
     * Untuk random posisi axis Y
     * @return int hasil random;
     */
    public int randomYpos() {
        int rand = this.rand.nextInt(6) + 5;

        return rand;

    }

    /**
     * Untuk random posisi axis X
     * @return int hasil random;
     */
    public int randomX() {
        int hasil = this.rand.nextInt((51) + 50) * -1;
        return hasil;
    }

    /**
     * Untuk inisialisasi physic
     */
    public void setPhysic() {
        //etupAnimationController();
        bulletAppState = new BulletAppState();
        bulletAppState.setDebugEnabled(false);

    }

    /**
     * Untuk inisialisasi scene
     */
    public void setScene() {
        //Spatial scene = assetManager.loadModel("Scenes/TestScene.j3o");

        Spatial scene = sc.getModelScene();//Masukan sinbad ke scene
        localRootNode.attachChild(scene);//masangin scene ke local
        scene.getParent().rotate(0, -190, 0);

    }

    /**
     * Untuk membuat player
     */
    public void createPlayer() {
//        player = localRootNode.getChild("Player");
//
//        BoundingBox boundingBox = (BoundingBox) player.getWorldBound();
//
//        float rad = boundingBox.getXExtent();
//        float height = boundingBox.getYExtent();
//        CapsuleCollisionShape playerShape = new CapsuleCollisionShape(rad, height);
//        playerControl = new CharacterControl(playerShape, 1.0f);
//        player.addControl(playerControl);
//        bulletAppState.getPhysicsSpace().add(playerControl);
//        playerControl.setPhysicsLocation(new Vector3f(-40f, 0.99419403f, 0.4776468f));
//
//        this.movement();
        chara.createPlayer(player, localRootNode);
        player.addControl(chara.getPlayerControl());
        bulletAppState.getPhysicsSpace().add(chara.getPlayerControl());
        this.playerControl.setPhysicsLocation(new Vector3f(-40f, 0.99419403f, 0.4776468f));
        this.movement();

    }
    
//    public void setPlayerControl(CharacterControl c){
//        playerControl = c;
//        
//    }
//    
//    public void addControl(){
//        player.addControl(playerControl);
//
//    }
//    
//    public void setPhysicLocation(){
//        this.playerControl.setPhysicsLocation(new Vector3f(-40f, 0.99419403f, 0.4776468f));
//
//    }
    

    /**
     * Untuk mengatur pergerakan dan animasi
     */
    public void movement() {
        //Animation
        animationControl = mov.getAnim(player);
       

        animationControl.addListener(this);
        animationChannel = animationControl.createChannel();

        //IO
            //IO
       mov.getInput(actionListener);

    }

    /**
     * Untuk membuat langit
     */
    private void createSky() {
        Spatial langitz = this.langit.createSky();
        localRootNode.attachChild(langitz);

    }

    /**
     * Untuk initialisasi suara lompat
     */
    public void initAudioJump() {

        audioJump = audio.initAudioJump();
        localRootNode.attachChild(audioJump);
    }

    /**
     * Untuk initialisasi suara tabrakan
     */
    public void initAudioTabrak() {
        /* Berbunyi jika tabrakan. */
        audioTabrak = audio.initAudioTabrak();
        localRootNode.attachChild(audioTabrak);
    }

    /**
     * Untuk memutar suara lompat
     */
    public void jumpSound() {
        nodeBGM = audio.jumpSound();
        localRootNode.attachChild(nodeBGM);
        nodeBGM.play();

    }

    /**
     * Initialisasi awal yang merupakan override dari kelas induk
     * @param stateManager
     * @param app 
     */
    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);
        this.jumpSound();

        this.setPhysic();
        stateManager.attach(bulletAppState);
        rootNode.attachChild(localRootNode);

        //scene
        this.setScene();
        //score
        defaultFont = assetManager.loadFont("Interface/Fonts/Default.fnt");
        pressStart = new BitmapText(defaultFont, false);
        fpsScoreText = new BitmapText(defaultFont, false);

        loadText(fpsScoreText, "Current Score: 0", defaultFont, 0, 2 + 5, 0);
        loadText(pressStart, "PRESS ENTER", defaultFont, 0, 5 + 5, 0);

        //Floor part
        this.Tanah();

        //audio
        //init audio jump
        initAudioJump();

        //init audio tabrak
        initAudioTabrak();
        //score
        text.setBox(new Rectangle(0, 0, 1360, 768));
        text.setSize(fnt.getPreferredSize() * 2f);
        text.setText("jojo");
        text.setLocalTranslation(0, 5, 0);
        localRootNode.attachChild(text);

        this.createSky();
//       
        //Player part
        this.createPlayer();

        flyByCamera.setEnabled(false);
        chaseCam = new ChaseCamera(camera, player, inputManager);

        //obs2 part
        this.obstacle();

        this.obstacleBird();

    }

    /**
     * Untuk menangkap interaksi yang terjadi di dalam game
     */
    protected final ActionListener actionListener = new ActionListener() {
        @Override
        public void onAction(String name, boolean keyPressed, float tpf) {
            if (keyPressed) {
                animationChannel.setAnim("RunBase");

            }

            if (name.equals(
                    "Pause") && !keyPressed) {
                setEnabled(!isEnabled());
            } else if (name.equals("Up")) {
                up = true;

            } else if (name.equals(
                    "Down")) {
                up = false;
                down = keyPressed;
                up = false;

            } else if (name.equals(
                    "Left")) {
                up = false;

                left = keyPressed;

            } else if (name.equals("Right")) {
                up = false;
                right = keyPressed;

            } else if (name.equals(
                    "Jump")) {

                playerControl.jump();
                playerControl.setJumpSpeed(20);

                if (keyPressed) {
                    animationChannel.setAnim("JumpLoop");
                    audioJump.playInstance(); // membunyikan suara sekali
                } else {
                    animationChannel.setAnim("IdleBase");
                    animationChannel.setAnim("RunBase");

                }
            } else if (name.equals("Go")) { // go
                statusPause = true;
                playerControl.setPhysicsLocation(new Vector3f(-40f, 0.99419403f, 0.4776468f));
                obsCon.setPhysicsLocation(new Vector3f(-100f, 0.99419403f, 0.4776468f));
                obsCon2.setPhysicsLocation(new Vector3f(-100f, 0.99419403f, 0.4776468f));
                score += 1;
                System.out.println(score + "ini score");

            } else if (name.equals("Pausez")) // pause 
            {
                statusPause = false;
            } else if (name.equals("Resume") && statusPause == false) // resume
            {
                statusPause = true;

            }

            if (!keyPressed) {
                up = false;
            }

        }
    };

    /**
     * Untuk mengupdate yang terjadi dalam game secara real time
     * @param tpf 
     */
    @Override
    public void update(float tpf) {
        Vector3f camDir = camera.getDirection().clone();
        Vector3f camLeft = camera.getLeft().clone();
        camDir.y = 0;
        camLeft.y = 0;

        Vector3f dir = new Vector3f(-0.96940863f, 0.0f, 0.018936336f);
        chaseCam.setDefaultDistance(10f);
        chaseCam.setDefaultVerticalRotation(0.25f);

        camDir.normalizeLocal();
        camLeft.normalizeLocal();

        playerWalkDirection.set(0, 0, 0);
        playerControl.setViewDirection(camLeft);

        if (left) {
            playerWalkDirection.add(camLeft);
            playerWalkDirection.set(0, 0, 5);

        }
        if (right) {
            playerWalkDirection.add(camLeft.negate());
            playerWalkDirection.set(0, 0, -5);
        }
        if (up) {
            playerWalkDirection.add(camDir);
            //playerWalkDirection.set(-5, 0, 0);

        }
        if (down) {
            playerWalkDirection.add(camDir.negate());
            playerWalkDirection.set(5, 0, 0);
        }

        if (player != null) {
            playerWalkDirection.multLocal(10f).multLocal(tpf);
            playerControl.setWalkDirection(playerWalkDirection);
        }

        if (statusPause == true) {
            nodeBGM.play();

            if (obsCon.getPhysicsLocation().x < -10) {

                obsCon.setPhysicsLocation(new Vector3f(obsCon.getPhysicsLocation().x + tpf * 25, obsCon.getPhysicsLocation().y, obsCon.getPhysicsLocation().z));
                obsCon2.setPhysicsLocation(new Vector3f(obsCon2.getPhysicsLocation().x + tpf * 25, 7, 0.5f));

                // System.out.println(obsCon.getPhysicsLocation().x + " ini obs");
                score += 1;
                //System.out.println("ini score" + score);

            } else {

                obsCon.setPhysicsLocation(new Vector3f(-100, 0.99419403f, this.RandomZPos()));
                System.out.println(this.RandomZPos());
                obsCon2.setPhysicsLocation(new Vector3f(-75, this.randomYpos(), this.RandomZPos()));

            }

            if (playerControl.getPhysicsLocation().x > -39 || playerControl.getPhysicsLocation().z <= -2.7206101 || playerControl.getPhysicsLocation().z >= 2.7206101) {

                statusPause = false;
                animationChannel.setAnim("IdleBase");
                score = 0;
                System.out.println("reset" + score);

                audioTabrak.playInstance();
                nodeBGM.stop();

            }

        }
    }

    /**
     * Untuk mengatur yang terjadi ketika siklus animasi selesai
     * @param control
     * @param channel
     * @param animName 
     */
    @Override
    public void onAnimCycleDone(AnimControl control, AnimChannel channel, String animName) {

    }

    /**
     * Untuk mengatur yang terjadi saat perubahan animasi
     * @param control
     * @param channel
     * @param animName 
     */
    @Override
    public void onAnimChange(AnimControl control, AnimChannel channel, String animName) {

    }

    /**
     * Untuk mengatur yang terjadi ketika ada pemicu
     * @param name
     * @param isPressed
     * @param tpf 
     */
    @Override
    public void onAction(String name, boolean isPressed, float tpf) {

    }

}
