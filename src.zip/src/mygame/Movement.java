/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.animation.AnimControl;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import com.jme3.asset.AssetManager;
import com.jme3.input.InputManager;
import com.jme3.input.KeyInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.scene.Spatial;

/**
 *
 * @author A S U S
 */
public class Movement extends AbstractAppState {

    AssetManager assetManager;
    AnimControl animationControl;
    InputManager inputManager;

    /**
     * Constructor kelas Movement
     * @param app 
     */
    public Movement(SimpleApplication app) {
        assetManager = app.getAssetManager();
        inputManager = app.getInputManager();

    }

    /**
     * Untuk mendapatkan animasi
     * @param player
     * @return 
     */
    public AnimControl getAnim(Spatial player) {
        animationControl = player.getParent().getControl(AnimControl.class);
        return animationControl;

    }

    /**
     * Menerima input pergerakan yang diinginkan user
     * @param actionListener 
     */
    public void getInput( ActionListener actionListener) {
        //IO
        inputManager.addMapping("Up", new KeyTrigger(KeyInput.KEY_W));
        inputManager.addMapping("Down", new KeyTrigger(KeyInput.KEY_S));
        inputManager.addMapping("Left", new KeyTrigger(KeyInput.KEY_A));
        inputManager.addMapping("Right", new KeyTrigger(KeyInput.KEY_D));
        inputManager.addMapping("Jump", new KeyTrigger(KeyInput.KEY_SPACE));
        inputManager.addMapping("Go", new KeyTrigger(KeyInput.KEY_P));
        inputManager.addMapping("Resume", new KeyTrigger(KeyInput.KEY_F10));

        inputManager.addMapping("Pausez", new KeyTrigger(KeyInput.KEY_F9));
        inputManager.addListener(actionListener, "Pause", "Up", "Down", "Left", "Right", "Jump");

        inputManager.addListener(actionListener, "Pausez", "Go", "Resume");
    }

}
