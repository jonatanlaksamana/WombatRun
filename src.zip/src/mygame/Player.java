/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import com.jme3.asset.AssetManager;
import com.jme3.bounding.BoundingBox;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.control.CharacterControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;

/**
 *
 * @author A S U S
 */
public class Player extends AbstractAppState {

    AssetManager assetManager;
    Node localRootNode = new Node("scene");
    Node rootNode;

    /**
     * Constructor kelas Player
     * @param app 
     */
    public Player(SimpleApplication app) {
        rootNode = app.getRootNode();
        assetManager = app.getAssetManager();

    }

    /**
     * Untuk mendapatkan player
     * @param path
     * @return 
     */
    public Spatial getPlayer(String path) {
        Spatial scene = assetManager.loadModel(path);//Masukan sinbad ke scene
        localRootNode.attachChild(scene);//masangin scene ke local

        return scene;
    }

    /**
     * Untuk mendapatkan CharacterControl
     * @param path
     * @param player
     * @param obsCon2
     * @return 
     */
    public CharacterControl a(String path, Spatial player, RigidBodyControl obsCon2) {
        Spatial bird = this.getPlayer(path);

        System.out.println(bird.getLocalTranslation());
        BoundingBox bounding = (BoundingBox) player.getWorldBound();
        localRootNode.attachChild(bird);

        float rad3 = bounding.getXExtent();
        float height3 = bounding.getYExtent();
        CapsuleCollisionShape playerShape3 = new CapsuleCollisionShape(rad3, height3);
        return new CharacterControl(playerShape3, height3);

    }

}
